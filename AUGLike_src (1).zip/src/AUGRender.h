//
//  AUGRender.h
//
#pragma once
#include "ModuleControl.h"
#include "UnityBridge.h"

void AUGRenderFrame(ModuleControl *mc);

// 菜单开关（悬浮球调用）
void AUGSetMenuOpen(bool v);
bool AUGGetMenuOpen(void);

// 自瞄（Aimbot.mm）
void AUGAimStep(ModuleControl *mc, AUGEntity *list, int n);
int  AUGPickTarget(AUGEntity *list, int n, CGPoint center, float maxR, int *outIndex);
