//
//  UnityBridge.h —— 游戏侧对接层
//
//  数据来源已经确认：游戏通过一组原生接口喂球体数据
//    AddPlayer / AddBall / DelBall / MoveBall / SetScore（RVA 见 BallHook.mm）
//  我们 hook 这些接口，维护自己的球表，ESP 直接从表里画。
//
#pragma once
#include <stdint.h>

#define AUG_MAX_ENTITIES 256

typedef struct {
    int userid;
    int ballid;
    int x, y;        // 游戏内坐标
    int score;       // 分数（决定球大小）
    int teamid;
    int alive;
} BallRec;

typedef struct {
    int x, y, score;
} AUGFeed;

typedef struct {
    float screen_x, screen_y;
    float radius;      // 屏幕半径（像素）
    float score;
    int   visible;
    char  name[32];
    float wx, wy;      // 原始坐标
} AUGEntity;

typedef struct {
    float x, y;
} AUGPoint;

int  AUGUnityInit(void);                             // 安装 hook，返回 0 成功
int  AUGInstallBallHooks(void);                      // 内部用
int  AUGCopyBalls(BallRec *out, int maxCount);       // 取球表快照
int  AUGCopyFeeds(AUGFeed *out, int maxCount);       // 取食物点位
int  AUGLastBreak(int *userid, int *percent, uint64_t *when);   // 分裂事件
int  AUGCollectEntities(AUGEntity *out, int maxCount);
int  AUGWorldToScreen(float wx, float wy, float wz, AUGPoint *out);
void AUGAimAt(const AUGEntity *e, float speed);
