//
//  FloatingBall.mm —— 悬浮球（对应原包 _0xD4E9A3C7）
//
//  拖动移动、单击开关菜单、长按隐藏/显示。
//
#import "AUGLike.h"
#include <cmath>
#include "AUGRender.h"

@implementation AUGFloatingBall {
    CGPoint _startTouch;
    CGPoint _startCenter;
    BOOL    _dragging;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
        self.layer.cornerRadius = frame.size.width / 2;
        self.layer.borderWidth = 1;
        self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.35].CGColor;
        self.userInteractionEnabled = YES;

        UILabel *icon = [[UILabel alloc] initWithFrame:self.bounds];
        icon.text = @"A";
        icon.textColor = [UIColor whiteColor];
        icon.font = [UIFont boldSystemFontOfSize:22];
        icon.textAlignment = NSTextAlignmentCenter;
        [self addSubview:icon];

        UITapGestureRecognizer *tap =
            [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap)];
        [self addGestureRecognizer:tap];

        UILongPressGestureRecognizer *lp =
            [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(onLongPress:)];
        lp.minimumPressDuration = 0.8;
        [self addGestureRecognizer:lp];
    }
    return self;
}

- (void)onTap {
    AUGSetMenuOpen(!AUGGetMenuOpen());
}

- (void)onLongPress:(UILongPressGestureRecognizer *)g {
    if (g.state == UIGestureRecognizerStateBegan) {
        self.hidden = YES;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ self.hidden = NO; });
    }
}

/* 拖动 */
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    _startTouch = [t locationInView:self.superview];
    _startCenter = self.center;
    _dragging = NO;
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView:self.superview];
    CGFloat dx = p.x - _startTouch.x, dy = p.y - _startTouch.y;
    if (fabs(dx) + fabs(dy) > 4) _dragging = YES;
    if (_dragging) self.center = CGPointMake(_startCenter.x + dx, _startCenter.y + dy);
}

@end
