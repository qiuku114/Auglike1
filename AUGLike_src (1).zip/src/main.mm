//
//  main.mm —— dylib 入口：装窗口、装悬浮球、启动渲染循环
//
//  与原包差异：这里没有任何卡密/验签/授权文件逻辑。
//  AUGIsLicensed() 恒 YES，功能位直接可写。
//
#import "AUGLike.h"
#import <objc/runtime.h>
#include "UnityBridge.h"

ModuleControl gMC = {0};

static AUGOverlayWindow *gWindow = nil;
static AUGFloatingBall  *gBall   = nil;

void AUGStartOverlay(void) {
    if (gWindow) return;

    // 1) 叠加窗口：层级高于游戏窗口，但不抢普通触摸（hitTest 里放行）
    gWindow = [[AUGOverlayWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    gWindow.windowLevel = UIWindowLevelAlert - 1;
    gWindow.backgroundColor = [UIColor clearColor];
    gWindow.rootViewController = [UIViewController new];
    gWindow.hidden = NO;

    // 2) 渲染视图（Metal + ImGui），铺满全屏
    AUGOverlayView *view = [[AUGOverlayView alloc] initWithFrame:gWindow.bounds];
    view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [gWindow.rootViewController.view addSubview:view];

    // 3) 悬浮球：点它开关菜单
    gBall = [[AUGFloatingBall alloc] initWithFrame:CGRectMake(24, 160, 52, 52)];
    [gWindow.rootViewController.view addSubview:gBall];

    // 4) 默认开关（原包由卡密决定，这里直接给）
    gMC.enabled = true;
    gMC.main.a = true;      // 菜单总开关
    gMC.main.b = true;      // ESP
    gMC.main.c = false;     // 自瞄

    // 5) 挂游戏原生球体接口（AddBall/MoveBall/...）
    int rc = AUGUnityInit();
    NSLog(@"[AUGLike] ball hooks rc=%d", rc);
}

__attribute__((constructor))
static void AUGLikeInit(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        AUGStartOverlay();
    });
}
